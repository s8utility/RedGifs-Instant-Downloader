chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type !== "S8_DOWNLOAD" || !msg.url) return;
  chrome.downloads.download({ url: msg.url, saveAs: false });
});
