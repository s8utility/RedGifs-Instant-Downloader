s8utility.com RedGIFs Downloader v1.0

Adds a small download button to RedGIFs thumbnails and feed players.
The download URL is derived from the RedGIFs poster image URL.

Fix: does not modify the Player positioning or apply backdrop blur, avoiding interference with homepage video playback.

Made by s8utility.com
