(() => {
  const BTN_CLASS = 's8utility-download';

  function mp4FromImage(src) {
    if (!src) return null;
    try {
      const u = new URL(src, location.href);
      if (u.hostname !== 'media.redgifs.com') return null;
      const name = u.pathname.split('/').pop();
      if (!name) return null;
      const base = name
        .replace(/-(?:mobile|poster)(?=\.[^.]+$)/i, '')
        .replace(/\.(?:jpe?g|png|webp|avif)$/i, '');
      return base ? `https://media.redgifs.com/${base}.mp4` : null;
    } catch (_) { return null; }
  }

  function button(url) {
    const el = document.createElement('button');
    el.type = 'button';
    el.className = BTN_CLASS;
    el.title = 'Download video — made by s8utility.com';
    el.setAttribute('aria-label', 'Download video');
    el.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v10m0 0 4-4m-4 4-4-4M5 18v1.25A1.75 1.75 0 0 0 6.75 21h10.5A1.75 1.75 0 0 0 19 19.25V18"/></svg>';
    el.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      chrome.runtime.sendMessage({ type: 'S8_DOWNLOAD', url });
    }, true);
    return el;
  }

  function addToHost(host, url) {
    if (!host || !url || host.querySelector(':scope > .' + BTN_CLASS)) return;
    host.appendChild(button(url));
  }

  function scan() {
    // Explore/search/profile grids: derive the MP4 directly from every RedGIFs thumbnail.
    document.querySelectorAll('img[src*="media.redgifs.com/"]').forEach(img => {
      const url = mp4FromImage(img.currentSrc || img.src);
      if (!url) return;

      const tile = img.closest('.tileItem');
      if (tile) {
        addToHost(tile, url);
        return;
      }

      // Home/feed player posters.
      const player = img.closest('.Player');
      if (player) addToHost(player, url);
    });
  }

  let queued = false;
  function queueScan() {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; scan(); });
  }

  scan();
  new MutationObserver(queueScan).observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['src']
  });
  window.addEventListener('load', scan, { once: true });
  setTimeout(scan, 1000);
})();
